from django.contrib import admin
from .models import *

admin.site.register(Attendance)
admin.site.register(Notice)
admin.site.register(Marks)
# Register your models here.
